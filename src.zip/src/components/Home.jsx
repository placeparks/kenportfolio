import React from 'react'
import MainPage from './MainPAge'
function Home() {
  return (
    <div>
  <MainPage/>
    </div>
  )
}

export default Home
